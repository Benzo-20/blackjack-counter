import next from 'next';

/** @type {import('next').NextConfig} */
const config = {
  reactStrictMode: true,
};

export default config;
