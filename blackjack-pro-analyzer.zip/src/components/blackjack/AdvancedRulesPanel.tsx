"use client";

import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { cn } from "@/lib/utils";
import { Settings, ChevronDown, ChevronUp, Info } from "lucide-react";
import { AnimatePresence, motion } from "framer-motion";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { BlackjackRules } from "./RulesEngine";

const RULE_INFO: Record<string, string> = {
  numDecks:
    "Number of decks in the shoe. Fewer decks make counting easier but usually worse rules.",
  penetration:
    "How deep into the shoe before shuffle. Higher penetration = more profitable counting.",
  dealerHitsSoft17:
    "H17 = Dealer hits soft 17 (A+6). Worse for player (~−0.20%). S17 = Dealer stands.",
  blackjackPays:
    "3:2 is standard. 6:5 is very bad. 2:1 is extremely rare but excellent.",
  holeCardRule:
    "American = Dealer peeks for blackjack. ENHC = No hole card (dealer doesn't peek). EALOB = lose all bets on dealer blackjack.",
  doubleAllowed:
    "Which hands you can double on. 'Any' is best. Restrictions cost edge.",
  das: "Double After Split. Good for player.",
  doubleSoft: "Allows doubling on soft hands (A+X).",
  resplitAces: "Ability to resplit aces if you get another ace.",
  hitSplitAces: "Take multiple cards on split aces (usually only one).",
  splitTens: "Allows splitting tens/face cards. Strategically almost never good.",
  bjAfterSplit:
    "If blackjack after split counts as real blackjack (3:2 payout). Rare but good.",
  surrender:
    "Late = after dealer checks blackjack. Early = before check (strong rule for player).",
  insurance:
    "Side bet when dealer shows ace. Only take at TC ≥ +3 when counting.",
  nmse: "No Mid-Shoe Entry. Hurts wonging.",
  csm: "Continuous Shuffle Machine. Makes card counting essentially impossible.",
  push22:
    "Dealer 22 pushes vs all non-busted hands. Very bad rule for the player.",
  countingSystem:
    "Hi-Lo is standard and recommended. KO is simpler. Others are more advanced.",
  maxSplits: "Max number of times you can split (1-4).",
};

const InfoTooltip = ({ text }: { text: string }) => (
  <TooltipProvider delayDuration={100}>
    <Tooltip>
      <TooltipTrigger asChild>
        <Info className="ml-1 h-4 w-4 cursor-help text-slate-400 transition-colors hover:text-blue-600" />
      </TooltipTrigger>
      <TooltipContent className="max-w-xs">
        <p className="text-sm">{text}</p>
      </TooltipContent>
    </Tooltip>
  </TooltipProvider>
);

interface AdvancedRulesPanelProps {
  rules: BlackjackRules;
  setRules: (rules: BlackjackRules) => void;
  darkMode: boolean;
  showPanel: boolean;
  setShowPanel: (val: boolean) => void;
}

export default function AdvancedRulesPanel({
  rules,
  setRules,
  darkMode,
  showPanel,
  setShowPanel,
}: AdvancedRulesPanelProps) {
  return (
    <Card
      className={cn(
        "border-2 shadow-lg",
        darkMode ? "bg-slate-800 border-slate-700" : "bg-white border-slate-200"
      )}
    >
      <CardHeader
        className="cursor-pointer pb-3"
        onClick={() => setShowPanel(!showPanel)}
      >
        <div className="flex items-center justify-between">
          <CardTitle
            className={cn(
              "flex items-center gap-2 text-base md:text-lg",
              darkMode ? "text-white" : "text-slate-900"
            )}
          >
            <Settings className="h-5 w-5" />
            Advanced Casino Rules &amp; Settings
          </CardTitle>
          {showPanel ? <ChevronUp className="h-5 w-5" /> : <ChevronDown className="h-5 w-5" />}
        </div>
      </CardHeader>
      <AnimatePresence>
        {showPanel && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
          >
            <CardContent className="space-y-4 pt-0">
              <Separator className={darkMode ? "bg-slate-700" : ""} />

              <div className="grid gap-4 md:grid-cols-2 md:gap-6">
                {/* Left column */}
                <div className="space-y-4">
                  <div>
                    <label
                      className={cn(
                        "mb-2 flex items-center text-sm font-medium",
                        darkMode ? "text-slate-300" : "text-slate-700"
                      )}
                    >
                      Number of Decks
                      <InfoTooltip text={RULE_INFO.numDecks} />
                    </label>
                    <Select
                      value={rules.numDecks.toString()}
                      onValueChange={(v) =>
                        setRules({ ...rules, numDecks: parseInt(v, 10) })
                      }
                    >
                      <SelectTrigger
                        className={
                          darkMode ? "bg-slate-700 border-slate-600 text-white" : ""
                        }
                      >
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {[1, 2, 4, 6, 8].map((n) => (
                          <SelectItem key={n} value={n.toString()}>
                            {n} deck{n > 1 ? "s" : ""}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <label
                      className={cn(
                        "mb-2 flex items-center text-sm font-medium",
                        darkMode ? "text-slate-300" : "text-slate-700"
                      )}
                    >
                      Penetration: {rules.penetration}%
                      <InfoTooltip text={RULE_INFO.penetration} />
                    </label>
                    <Slider
                      value={[rules.penetration]}
                      onValueChange={(v) =>
                        setRules({ ...rules, penetration: v[0] as number })
                      }
                      min={50}
                      max={95}
                      step={5}
                    />
                  </div>

                  <div>
                    <label
                      className={cn(
                        "mb-2 flex items-center text-sm font-medium",
                        darkMode ? "text-slate-300" : "text-slate-700"
                      )}
                    >
                      Blackjack Payout
                      <InfoTooltip text={RULE_INFO.blackjackPays} />
                    </label>
                    <Select
                      value={rules.blackjackPays.toString()}
                      onValueChange={(v) =>
                        setRules({ ...rules, blackjackPays: parseFloat(v) })
                      }
                    >
                      <SelectTrigger
                        className={
                          darkMode ? "bg-slate-700 border-slate-600 text-white" : ""
                        }
                      >
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="2.0">2:1 (Rare - Very Good)</SelectItem>
                        <SelectItem value="1.5">3:2 (Standard)</SelectItem>
                        <SelectItem value="1.2">6:5 (Bad)</SelectItem>
                        <SelectItem value="1.0">1:1 (Very Bad)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <label
                      className={cn(
                        "mb-2 flex items-center text-sm font-medium",
                        darkMode ? "text-slate-300" : "text-slate-700"
                      )}
                    >
                      Hole Card Rule
                      <InfoTooltip text={RULE_INFO.holeCardRule} />
                    </label>
                    <Select
                      value={rules.holeCardRule}
                      onValueChange={(v) =>
                        setRules({ ...rules, holeCardRule: v as BlackjackRules["holeCardRule"] })
                      }
                    >
                      <SelectTrigger
                        className={
                          darkMode ? "bg-slate-700 border-slate-600 text-white" : ""
                        }
                      >
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="american">American (Dealer Peeks)</SelectItem>
                        <SelectItem value="enhc">European No Hole Card (ENHC)</SelectItem>
                        <SelectItem value="ealob">ENHC - Lose All Bets (EALOB)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <label
                      className={cn(
                        "mb-2 flex items-center text-sm font-medium",
                        darkMode ? "text-slate-300" : "text-slate-700"
                      )}
                    >
                      Double Allowed On
                      <InfoTooltip text={RULE_INFO.doubleAllowed} />
                    </label>
                    <Select
                      value={rules.doubleAllowed}
                      onValueChange={(v) =>
                        setRules({
                          ...rules,
                          doubleAllowed: v as BlackjackRules["doubleAllowed"],
                        })
                      }
                    >
                      <SelectTrigger
                        className={
                          darkMode ? "bg-slate-700 border-slate-600 text-white" : ""
                        }
                      >
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="any">Any 2 Cards</SelectItem>
                        <SelectItem value="8-11">8-11 Only</SelectItem>
                        <SelectItem value="9-11">9-11 Only</SelectItem>
                        <SelectItem value="10-11">10-11 Only</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <label
                      className={cn(
                        "mb-2 flex items-center text-sm font-medium",
                        darkMode ? "text-slate-300" : "text-slate-700"
                      )}
                    >
                      Surrender Type
                      <InfoTooltip text={RULE_INFO.surrender} />
                    </label>
                    <Select
                      value={rules.surrender}
                      onValueChange={(v) =>
                        setRules({
                          ...rules,
                          surrender: v as BlackjackRules["surrender"],
                        })
                      }
                    >
                      <SelectTrigger
                        className={
                          darkMode ? "bg-slate-700 border-slate-600 text-white" : ""
                        }
                      >
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">No Surrender</SelectItem>
                        <SelectItem value="late">Late Surrender</SelectItem>
                        <SelectItem value="early-10">Early vs 10</SelectItem>
                        <SelectItem value="early-ace">Early vs Ace</SelectItem>
                        <SelectItem value="early-both">Early vs 10 &amp; Ace</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <label
                      className={cn(
                        "mb-2 flex items-center text-sm font-medium",
                        darkMode ? "text-slate-300" : "text-slate-700"
                      )}
                    >
                      Counting System
                      <InfoTooltip text={RULE_INFO.countingSystem} />
                    </label>
                    <Select
                      value={rules.countingSystem}
                      onValueChange={(v) =>
                        setRules({ ...rules, countingSystem: v })
                      }
                    >
                      <SelectTrigger
                        className={
                          darkMode ? "bg-slate-700 border-slate-600 text-white" : ""
                        }
                      >
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Hi-Lo">Hi-Lo (Recommended)</SelectItem>
                        <SelectItem value="KO">Knock-Out (KO)</SelectItem>
                        <SelectItem value="Hi-Opt I">Hi-Opt I</SelectItem>
                        <SelectItem value="Hi-Opt II">Hi-Opt II</SelectItem>
                        <SelectItem value="Zen">Zen Count</SelectItem>
                        <SelectItem value="Omega II">Omega II</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Right column */}
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <label
                      className={cn(
                        "flex items-center text-sm font-medium",
                        darkMode ? "text-slate-300" : "text-slate-700"
                      )}
                    >
                      Dealer Hits Soft 17 (H17)
                      <InfoTooltip text={RULE_INFO.dealerHitsSoft17} />
                    </label>
                    <Switch
                      checked={rules.dealerHitsSoft17}
                      onCheckedChange={(v) =>
                        setRules({ ...rules, dealerHitsSoft17: v as boolean })
                      }
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <label
                      className={cn(
                        "flex items-center text-sm font-medium",
                        darkMode ? "text-slate-300" : "text-slate-700"
                      )}
                    >
                      Double After Split (DAS)
                      <InfoTooltip text={RULE_INFO.das} />
                    </label>
                    <Switch
                      checked={rules.das}
                      onCheckedChange={(v) =>
                        setRules({ ...rules, das: v as boolean })
                      }
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <label
                      className={cn(
                        "flex items-center text-sm font-medium",
                        darkMode ? "text-slate-300" : "text-slate-700"
                      )}
                    >
                      Double on Soft Hands
                      <InfoTooltip text={RULE_INFO.doubleSoft} />
                    </label>
                    <Switch
                      checked={rules.doubleSoft}
                      onCheckedChange={(v) =>
                        setRules({ ...rules, doubleSoft: v as boolean })
                      }
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <label
                      className={cn(
                        "flex items-center text-sm font-medium",
                        darkMode ? "text-slate-300" : "text-slate-700"
                      )}
                    >
                      Resplit Aces
                      <InfoTooltip text={RULE_INFO.resplitAces} />
                    </label>
                    <Switch
                      checked={rules.resplitAces}
                      onCheckedChange={(v) =>
                        setRules({ ...rules, resplitAces: v as boolean })
                      }
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <label
                      className={cn(
                        "flex items-center text-sm font-medium",
                        darkMode ? "text-slate-300" : "text-slate-700"
                      )}
                    >
                      Hit Split Aces
                      <InfoTooltip text={RULE_INFO.hitSplitAces} />
                    </label>
                    <Switch
                      checked={rules.hitSplitAces}
                      onCheckedChange={(v) =>
                        setRules({ ...rules, hitSplitAces: v as boolean })
                      }
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <label
                      className={cn(
                        "flex items-center text-sm font-medium",
                        darkMode ? "text-slate-300" : "text-slate-700"
                      )}
                    >
                      Allow Split Tens
                      <InfoTooltip text={RULE_INFO.splitTens} />
                    </label>
                    <Switch
                      checked={rules.splitTens}
                      onCheckedChange={(v) =>
                        setRules({ ...rules, splitTens: v as boolean })
                      }
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <label
                      className={cn(
                        "flex items-center text-sm font-medium",
                        darkMode ? "text-slate-300" : "text-slate-700"
                      )}
                    >
                      BJ After Split = Blackjack
                      <InfoTooltip text={RULE_INFO.bjAfterSplit} />
                    </label>
                    <Switch
                      checked={rules.bjAfterSplitCountsAsBJ}
                      onCheckedChange={(v) =>
                        setRules({
                          ...rules,
                          bjAfterSplitCountsAsBJ: v as boolean,
                        })
                      }
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <label
                      className={cn(
                        "flex items-center text-sm font-medium",
                        darkMode ? "text-slate-300" : "text-slate-700"
                      )}
                    >
                      Insurance Offered
                      <InfoTooltip text={RULE_INFO.insurance} />
                    </label>
                    <Switch
                      checked={rules.insurance}
                      onCheckedChange={(v) =>
                        setRules({ ...rules, insurance: v as boolean })
                      }
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <label
                      className={cn(
                        "flex items-center text-sm font-medium",
                        darkMode ? "text-slate-300" : "text-slate-700"
                      )}
                    >
                      No Mid-Shoe Entry (NMSE)
                      <InfoTooltip text={RULE_INFO.nmse} />
                    </label>
                    <Switch
                      checked={rules.nmse}
                      onCheckedChange={(v) =>
                        setRules({ ...rules, nmse: v as boolean })
                      }
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <label
                      className={cn(
                        "flex items-center text-sm font-medium",
                        darkMode ? "text-slate-300" : "text-slate-700"
                      )}
                    >
                      Continuous Shuffle Machine (CSM)
                      <InfoTooltip text={RULE_INFO.csm} />
                    </label>
                    <Switch
                      checked={rules.csm}
                      onCheckedChange={(v) =>
                        setRules({ ...rules, csm: v as boolean })
                      }
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <label
                      className={cn(
                        "flex items-center text-sm font-medium",
                        darkMode ? "text-slate-300" : "text-slate-700"
                      )}
                    >
                      Push 22 Rule
                      <InfoTooltip text={RULE_INFO.push22} />
                    </label>
                    <Switch
                      checked={rules.push22}
                      onCheckedChange={(v) =>
                        setRules({ ...rules, push22: v as boolean })
                      }
                    />
                  </div>
                </div>
              </div>

              <Separator className={darkMode ? "bg-slate-700" : ""} />

              <div>
                <label
                  className={cn(
                    "mb-2 block text-sm font-medium",
                    darkMode ? "text-slate-300" : "text-slate-700"
                  )}
                >
                  Quick Presets
                </label>
                <div className="flex flex-wrap gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() =>
                      setRules({
                        ...rules,
                        numDecks: 6,
                        dealerHitsSoft17: false,
                        holeCardRule: "american",
                        blackjackPays: 1.5,
                        das: true,
                        surrender: "none",
                        csm: false,
                      })
                    }
                    className={
                      darkMode
                        ? "border-slate-600 bg-slate-700 text-white hover:bg-slate-600"
                        : ""
                    }
                  >
                    Standard Vegas
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() =>
                      setRules({
                        ...rules,
                        numDecks: 8,
                        dealerHitsSoft17: false,
                        holeCardRule: "enhc",
                        blackjackPays: 1.5,
                        das: true,
                        surrender: "none",
                      })
                    }
                    className={
                      darkMode
                        ? "border-slate-600 bg-slate-700 text-white hover:bg-slate-600"
                        : ""
                    }
                  >
                    European
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() =>
                      setRules({
                        ...rules,
                        blackjackPays: 1.2,
                        dealerHitsSoft17: true,
                        das: false,
                      })
                    }
                    className={
                      darkMode
                        ? "border-slate-600 bg-slate-700 text-white hover:bg-slate-600"
                        : ""
                    }
                  >
                    Bad 6:5 Game
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() =>
                      setRules({
                        ...rules,
                        csm: true,
                      })
                    }
                    className={
                      darkMode
                        ? "border-slate-600 bg-slate-700 text-white hover:bg-slate-600"
                        : ""
                    }
                  >
                    CSM Table
                  </Button>
                </div>
              </div>
            </CardContent>
          </motion.div>
        )}
      </AnimatePresence>
    </Card>
  );
}
