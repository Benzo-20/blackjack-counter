// Complete Blackjack rules engine with all variations

export interface BlackjackRules {
  numDecks: number;
  penetration: number;
  dealerHitsSoft17: boolean;
  holeCardRule: "american" | "enhc" | "ealob";
  blackjackPays: number;
  doubleAllowed: "any" | "9-11" | "10-11" | "8-11";
  das: boolean;
  doubleSoft: boolean;
  maxSplits: number;
  resplitAces: boolean;
  hitSplitAces: boolean;
  splitTens: boolean;
  bjAfterSplitCountsAsBJ: boolean;
  surrender: "none" | "late" | "early-10" | "early-ace" | "early-both";
  insurance: boolean;
  nmse: boolean;
  csm: boolean;
  push22: boolean;
  countingSystem: string;
}

export const DEFAULT_COMPREHENSIVE_RULES: BlackjackRules = {
  numDecks: 6,
  penetration: 75,
  dealerHitsSoft17: false,
  holeCardRule: "american",
  blackjackPays: 1.5,
  doubleAllowed: "any",
  das: true,
  doubleSoft: true,
  maxSplits: 3,
  resplitAces: false,
  hitSplitAces: false,
  splitTens: true,
  bjAfterSplitCountsAsBJ: false,
  surrender: "late",
  insurance: true,
  nmse: false,
  csm: false,
  push22: false,
  countingSystem: "Hi-Lo",
};

export const EV_MODIFIERS = {
  h17: 0.2,
  blackjack_6to5: 1.39,
  blackjack_1to1: 2.3,
  blackjack_2to1: -0.7,
  enhc: 0.11,
  ealob: 0.2,
  no_soft_double: 0.14,
  double_10_11_only: 0.28,
  double_9_11_only: 0.15,
  double_8_11_only: 0.1,
  no_das: 0.14,
  no_resplit_aces: 0.07,
  no_hit_split_aces: 0.19,
  bj_after_split_counts: -0.12,
  late_surrender: -0.07,
  early_surrender_10: -0.24,
  early_surrender_ace: -0.39,
  early_surrender_both: -0.63,
  nmse: 0.04,
  push22: 1.4,
  fewer_decks_per_deck: -0.06,
};

export function calculateBaseHouseEdge(rules: BlackjackRules): number {
  let houseEdge = 0.48; // Base for 6D S17 DAS 3:2

  const deckDiff = 6 - rules.numDecks;
  houseEdge -= deckDiff * EV_MODIFIERS.fewer_decks_per_deck;

  if (rules.dealerHitsSoft17) {
    houseEdge += EV_MODIFIERS.h17;
  }

  if (rules.blackjackPays === 1.2) {
    houseEdge += EV_MODIFIERS.blackjack_6to5;
  } else if (rules.blackjackPays === 1.0) {
    houseEdge += EV_MODIFIERS.blackjack_1to1;
  } else if (rules.blackjackPays === 2.0) {
    houseEdge += EV_MODIFIERS.blackjack_2to1;
  }

  if (rules.holeCardRule === "enhc") {
    houseEdge += EV_MODIFIERS.enhc;
  } else if (rules.holeCardRule === "ealob") {
    houseEdge += EV_MODIFIERS.ealob;
  }

  if (!rules.doubleSoft) {
    houseEdge += EV_MODIFIERS.no_soft_double;
  }

  if (rules.doubleAllowed === "10-11") {
    houseEdge += EV_MODIFIERS.double_10_11_only;
  } else if (rules.doubleAllowed === "9-11") {
    houseEdge += EV_MODIFIERS.double_9_11_only;
  } else if (rules.doubleAllowed === "8-11") {
    houseEdge += EV_MODIFIERS.double_8_11_only;
  }

  if (!rules.das) {
    houseEdge += EV_MODIFIERS.no_das;
  }

  if (!rules.resplitAces) {
    houseEdge += EV_MODIFIERS.no_resplit_aces;
  }

  if (!rules.hitSplitAces) {
    houseEdge += EV_MODIFIERS.no_hit_split_aces;
  }

  if (rules.bjAfterSplitCountsAsBJ) {
    houseEdge += EV_MODIFIERS.bj_after_split_counts;
  }

  if (rules.surrender === "late") {
    houseEdge += EV_MODIFIERS.late_surrender;
  } else if (rules.surrender === "early-10") {
    houseEdge += EV_MODIFIERS.early_surrender_10;
  } else if (rules.surrender === "early-ace") {
    houseEdge += EV_MODIFIERS.early_surrender_ace;
  } else if (rules.surrender === "early-both") {
    houseEdge += EV_MODIFIERS.early_surrender_both;
  }

  if (rules.nmse) {
    houseEdge += EV_MODIFIERS.nmse;
  }

  if (rules.push22) {
    houseEdge += EV_MODIFIERS.push22;
  }

  return houseEdge;
}

export function calculateCountAdjustedEV(
  baseHouseEdge: number,
  trueCount: number,
  rules: BlackjackRules
): number {
  if (rules.csm) {
    return -baseHouseEdge;
  }
  const countAdvantage = trueCount * 0.5;
  return countAdvantage - baseHouseEdge;
}

export function recommendBetUnits(trueCount: number, rules: BlackjackRules): number {
  if (rules.csm) return 1;
  if (trueCount <= 0) return 0;
  if (trueCount === 1) return 1;
  if (trueCount === 2) return 2;
  if (trueCount === 3) return 4;
  if (trueCount === 4) return 6;
  if (trueCount >= 5) return 8;
  return 1;
}
