"use client";

import React, { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Input } from "@/components/ui/input";
import {
  DEFAULT_COMPREHENSIVE_RULES,
  BlackjackRules,
  calculateBaseHouseEdge,
  calculateCountAdjustedEV,
  recommendBetUnits,
} from "@/components/blackjack/RulesEngine";
import {
  getCountingSystem,
  calculateRunningCount,
  calculateTrueCount,
} from "@/components/blackjack/CountingSystems";
import { generateStrategyResponse } from "@/components/blackjack/StrategyEngine";
import AdvancedRulesPanel from "@/components/blackjack/AdvancedRulesPanel";
import { cn } from "@/lib/utils";

const CARD_VALUES = [
  "2",
  "3",
  "4",
  "5",
  "6",
  "7",
  "8",
  "9",
  "10",
  "J",
  "Q",
  "K",
  "A",
];

type HandType = "hard" | "soft" | "pairs";

function createInitialShoe(numDecks: number) {
  const deck: string[] = [];
  for (let d = 0; d < numDecks; d++) {
    for (const v of CARD_VALUES) {
      const count = v === "10" || v === "J" || v === "Q" || v === "K" ? 4 : 4;
      for (let i = 0; i < count; i++) {
        deck.push(v);
      }
    }
  }
  // simple shuffle
  for (let i = deck.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [deck[i], deck[j]] = [deck[j], deck[i]];
  }
  return deck;
}

export default function Page() {
  const [darkMode, setDarkMode] = useState(true);
  const [rules, setRules] = useState<BlackjackRules>({
    ...DEFAULT_COMPREHENSIVE_RULES,
  });
  const [shoe, setShoe] = useState<string[]>(() =>
    createInitialShoe(DEFAULT_COMPREHENSIVE_RULES.numDecks)
  );
  const [discardTray, setDiscardTray] = useState<string[]>([]);
  const [runningCount, setRunningCount] = useState(0);
  const [handType, setHandType] = useState<HandType>("hard");
  const [handValue, setHandValue] = useState("16");
  const [dealerCard, setDealerCard] = useState("10");
  const [strategyOutput, setStrategyOutput] = useState<any | null>(null);
  const [showAdvancedRules, setShowAdvancedRules] = useState(true);

  useEffect(() => {
    const system = getCountingSystem(rules.countingSystem);
    const rc = calculateRunningCount(discardTray, rules.countingSystem);
    setRunningCount(rc);
  }, [discardTray, rules.countingSystem]);

  const dealCard = () => {
    if (shoe.length === 0) return;
    const card = shoe[0];
    setShoe((prev) => prev.slice(1));
    setDiscardTray((prev) => [...prev, card]);
  };

  const resetShoe = () => {
    const newShoe = createInitialShoe(rules.numDecks);
    setShoe(newShoe);
    setDiscardTray([]);
    setRunningCount(0);
    setStrategyOutput(null);
  };

  const getRemainingDecks = () => {
    return (shoe.length / 52) || 0.0001;
  };

  const analyzeSpot = () => {
    const decksRemaining = getRemainingDecks();
    const tc = calculateTrueCount(runningCount, decksRemaining, rules.countingSystem);

    const result = generateStrategyResponse(
      handType,
      handValue,
      dealerCard,
      tc,
      rules
    );
    setStrategyOutput(result);
  };

  const baseHouseEdge = calculateBaseHouseEdge(rules);
  const decksRemaining = getRemainingDecks();
  const trueCount = calculateTrueCount(runningCount, decksRemaining, rules.countingSystem);
  const countAdjustedEV = calculateCountAdjustedEV(baseHouseEdge, trueCount, rules);
  const betUnits = recommendBetUnits(trueCount, rules);

  return (
    <main
      className={cn(
        "min-h-screen p-4 md:p-8",
        darkMode ? "bg-slate-950 text-slate-50" : "bg-slate-100 text-slate-900"
      )}
    >
      <div className="mx-auto max-w-6xl space-y-6">
        {/* Header */}
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h1 className="text-2xl font-bold md:text-3xl">
              Blackjack Pro Analyzer
            </h1>
            <p className="text-sm text-slate-400">
              Card counting trainer · EV calculator · Strategy deviations
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Badge className="bg-emerald-600 text-white">
              RC: {runningCount >= 0 ? "+" : ""}
              {runningCount} | TC: {trueCount.toFixed(1)}
            </Badge>
            <Badge className="bg-slate-700 text-slate-50">
              {rules.countingSystem}
            </Badge>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setDarkMode((d) => !d)}
            >
              {darkMode ? "Light mode" : "Dark mode"}
            </Button>
          </div>
        </div>

        {/* Top row: shoe + EV */}
        <div className="grid gap-4 md:grid-cols-2">
          <Card className={darkMode ? "bg-slate-900 border-slate-800" : ""}>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Shoe &amp; Count Control</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex flex-wrap items-center gap-2">
                <Button onClick={dealCard}>Deal 1 card</Button>
                <Button variant="outline" onClick={resetShoe}>
                  New Shoe
                </Button>
                <Badge className="bg-slate-800 text-xs text-slate-100">
                  Shoe cards left: {shoe.length}
                </Badge>
                <Badge className="bg-slate-800 text-xs text-slate-100">
                  Discard tray: {discardTray.length}
                </Badge>
              </div>

              <Separator className="bg-slate-800" />

              <div className="space-y-2 text-sm">
                <p>
                  <span className="font-semibold">Running Count:</span>{" "}
                  {runningCount >= 0 ? "+" : ""}
                  {runningCount}
                </p>
                <p>
                  <span className="font-semibold">True Count:</span>{" "}
                  {trueCount.toFixed(2)} (decks left ~ {decksRemaining.toFixed(2)})
                </p>
              </div>
            </CardContent>
          </Card>

          <Card className={darkMode ? "bg-slate-900 border-slate-800" : ""}>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">EV &amp; Game Quality</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 text-sm">
              <p>
                <span className="font-semibold">Base house edge:</span>{" "}
                {baseHouseEdge.toFixed(2)}%
              </p>
              <p>
                <span className="font-semibold">Count-adjusted EV:</span>{" "}
                {countAdjustedEV.toFixed(2)}%
              </p>
              <p>
                <span className="font-semibold">Recommended bet spread:</span>{" "}
                {betUnits === 0
                  ? "Wong out / table minimum"
                  : `${betUnits} units`}
              </p>
              <p className="text-xs text-slate-400">
                EV estimates are approximate using a linear 0.5% per true count
                point model.
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Hand input + strategy */}
        <Card className={darkMode ? "bg-slate-900 border-slate-800" : ""}>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">Spot Analyzer</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid gap-4 md:grid-cols-4">
              <div>
                <label className="mb-1 block text-sm font-medium">
                  Hand Type
                </label>
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    variant={handType === "hard" ? "default" : "outline"}
                    onClick={() => setHandType("hard")}
                  >
                    Hard
                  </Button>
                  <Button
                    size="sm"
                    variant={handType === "soft" ? "default" : "outline"}
                    onClick={() => setHandType("soft")}
                  >
                    Soft
                  </Button>
                  <Button
                    size="sm"
                    variant={handType === "pairs" ? "default" : "outline"}
                    onClick={() => setHandType("pairs")}
                  >
                    Pair
                  </Button>
                </div>
              </div>

              <div>
                <label className="mb-1 block text-sm font-medium">
                  Player Hand Value
                </label>
                <Input
                  value={handValue}
                  onChange={(e) => setHandValue(e.target.value)}
                  placeholder={handType === "soft" ? "e.g. 18 (A,7)" : "e.g. 16"}
                />
              </div>

              <div>
                <label className="mb-1 block text-sm font-medium">
                  Dealer Upcard
                </label>
                <Input
                  value={dealerCard}
                  onChange={(e) => setDealerCard(e.target.value.toUpperCase())}
                  placeholder="2-10, J, Q, K, A"
                />
              </div>

              <div className="flex items-end">
                <Button className="w-full" onClick={analyzeSpot}>
                  Analyze Spot
                </Button>
              </div>
            </div>

            {strategyOutput && (
              <>
                <Separator className="bg-slate-800" />
                <div className="space-y-2 text-sm">
                  <p>
                    <span className="font-semibold">Recommended action:</span>{" "}
                    <span className="uppercase">
                      {strategyOutput.recommended_action}
                    </span>
                  </p>
                  {strategyOutput.take_insurance && (
                    <p className="text-amber-400">
                      Take insurance (TC ≥ +3 according to Illustrious 18).
                    </p>
                  )}
                  <p>
                    <span className="font-semibold">Spot EV (approx):</span>{" "}
                    {strategyOutput.count_adjusted_ev.toFixed(2)}%
                  </p>
                  <p className="text-slate-300">
                    {strategyOutput.reasoning}
                  </p>
                </div>
              </>
            )}
          </CardContent>
        </Card>

        {/* Advanced rules */}
        <AdvancedRulesPanel
          rules={rules}
          setRules={setRules}
          darkMode={darkMode}
          showPanel={showAdvancedRules}
          setShowPanel={setShowAdvancedRules}
        />

        <p className="text-center text-xs text-slate-500">
          For educational purposes only. Always follow local laws and casino rules.
        </p>
      </div>
    </main>
  );
}
